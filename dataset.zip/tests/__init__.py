"""Testes automatizados do desafio."""
